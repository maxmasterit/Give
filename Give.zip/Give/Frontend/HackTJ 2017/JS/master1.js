// This is a  line JS comment
/*
   This is a segment JS comment
*/

//var x = 5; // global
//below selector is for selecting tags
//old link for AID for AIDS pic: https://psdgd1whitefall11.files.wordpress.com/2011/10/afa_international_logo_repro.jpg
$(document).ready(function()
{
	var imageArray = ["https://pbs.twimg.com/profile_images/723592437495685120/0EHwBNff.jpg",
					  "https://pbs.twimg.com/profile_images/471517109134962688/TP51FR-V.png",
					  "https://thinkingglobal.wikispaces.com/file/view/doctors-without-borders.jpg/133141019/231x216/doctors-without-borders.jpg",
					  "https://upload.wikimedia.org/wikipedia/en/3/31/Autism_Speaks_Logo.jpg",
					  "https://cdnfiles.crowdrise.com/Prod_Medium/user_photo-547df857efef7.png",
					  "http://www.sidgmorefoundation.com/wp-content/uploads/2013/02/A-Wider-Circle-240-x-260.png",
					  "https://upload.wikimedia.org/wikipedia/en/thumb/6/69/Wounded_Warrior_Project_logo.svg/1200px-Wounded_Warrior_Project_logo.svg.png"];
	
	var namesArray = ["American Red Cross",
					  "Oxfam",
					  "Doctors Without Borders",
					  "Autism Speaks",
					  "AID for AIDS",
					  "A Wider Circle",
					  "Wounded Warrior Project"];

	var descriptions = ["The American Red Cross prevents and alleivates human suffering in the face of emergencies by mobilizing the power of volunteers "
								+ "and the generosity of donors.",
					  		 "Oxfam is a global movement of people working together to end the injustice of poverty",
					  		 "An independent humanitarian organization, Doctors Without Borders provides life-saving medical care to those affected by war, "
					  		 	+ "national disasters, disease outbreaks, systematic neglect or exclusion, and other crises",
					  		 "Autism Speaks is dedicated to promoting solutions, across the spectrum and throughout the lifespan, for the needs of individuals "
					  		 	+ "with autism and their families through advocacy and support; increasing understanding and acceptance of autism spectrum "
					  		 	+ "disorder; and advancing research into causes and better interventions for autism spectrum disorder and related conditions",
					  		 "AID for AIDS is a 501(c)(3) non-profit organization committed to empowering communities at risk of HIV and the population at "
					  		 	+ "large, by developing their abilities and capacities in comprehensive prevention through access to treatment, advocacy, "
					  		 	+ "education and training to improve their quality of life and reduce stigma and discrimination",
					  		 "The mission of A Wider Circle is simple: to end poverty for one individual and one family after another. They work in "
					  		 	+ "partnership with those seeking to help to ensure that every child and adult has the chance to succeed and the opportunity "
					  		 	+ "to live well",
					  		 "Wounded Warrior Project (WWP) serves veterans and service members who incurred a physical or mental injury, illness, or "
					  		 	+ "wound, co-incident to their military service on or after September 11, 2001 and their families."];

	var links = ["https://www.redcross.org",
				 "https://www.oxfam.org",
				 "https://www.doctorswithoutborders.org",
				 "https://www.autismspeaks.org",
				 "https://aidforaids.org",
				 "https://awidercircle.org",
				 "https://www.woundedwarriorproject.org"]			  		 	
	//document.getElementById("imgs").innerHTML = imageArray;
	/*
	imageArray[0] = new Image();
	imageArray[0].src = "https://pbs.twimg.com/profile_images/723592437495685120/0EHwBNff.jpg";
	imageArray[1] = new Image();
	imageArray[1].src = "https://pbs.twimg.com/profile_images/471517109134962688/TP51FR-V.png";
	imageArray[2] = new Image();
	imageArray[2].src = "https://donate.doctorswithoutborders.org/images/ecards/ephoto2.jpg?v=20151124";
	imageArray[3] = new Image();
	imageArray[3].src = "https://upload.wikimedia.org/wikipedia/en/3/31/Autism_Speaks_Logo.jpg";
	imageArray[4] = new Image();
	imageArray[4].src = "https://psdgd1whitefall11.files.wordpress.com/2011/10/afa_international_logo_repro.jpg";
	imageArray[5] = new Image();
	imageArray[5].src = "http://dev.afs401k.com/wp-content/uploads/2013/01/AWC-square-logo.jpg";
	imageArray[6] = new Image();
	imageArray[6].src = "https://upload.wikimedia.org/wikipedia/en/thumb/6/69/Wounded_Warrior_Project_logo.svg/1200px-Wounded_Warrior_Project_logo.svg.png";
	*/
	var i = 1;
	var count = 0;

	var img = document.getElementById('img1');
	// create a simple instance
	// by default, it only adds horizontal recognizers
	
	/*
	var mc = new Hammer(img);
	// listen to events...
	mc.on("swiperight ", function(ev)
	{
		//donate
		console.log(ev.type, "swipey right")
		if(count==0)
		{
			alert("Thank you for donating to " + namesArray[i-1])
		}
		else
		{
			alert("Thank you for donating to " + namesArray[i])
		}
		console.log("mc right i: " + i)
		console.log("mc right count: " + count)
	});
	mc.on("swipeleft ", function(ev)
	{
		//no donate, and go to next charity
		console.log(ev.type, "swipey left")
		console.log("mc left b4 i: " + i)
		console.log("mc left b4 count: " + count)
		if(count==0)
		{
			img.src=imageArray[i]
		}
		else
		{
			img.src=imageArray[i+1]
		}
		document.getElementById("p").innerHTML = ""
		document.getElementById('img1').style.display = 'initial'
		i++
		if(i==7)
		{
			i=0;
			count++;
		}
		console.log("mc left after i: " + i)
		console.log("mc left after count: " + count)
	});
	*/
	
	var box = document.getElementById('mainbox');
	var md = new Hammer(box);
	md.on("swiperight ", function(ev)
	{
		//donate
		if(count==0)
		{
			alert("Thank you for donating to " + namesArray[i-1])
		}
		else
		{
			if(img.src==imageArray[6])
			{
				alert("Thank you for donating to " + namesArray[6])
			}
			else
			{
				alert("Thank you for donating to " + namesArray[i-1])
			}
		}
	});
	md.on("swipeleft ", function(ev)
	{
		//no donate, and go to next charity
		console.log(ev.type, "swipey left")
		img.src=imageArray[i]
		document.getElementById("p").innerHTML = ""
		document.getElementById('img1').style.display = 'initial'
		i++
		if(i>6)
		{
			i=0;
			count++;
		}
	});	

	$('#img1').click(function()
	{
		document.getElementById('img1').style.display = 'none'
		if(count==0)
		{
			document.getElementById("p").innerHTML = descriptions[i-1]
		}
		else
		{
			if(img.src==imageArray[6])
			{
				document.getElementById("p").innerHTML = descriptions[6]	
			}
			else
			{
				document.getElementById("p").innerHTML = descriptions[i-1]	
			}
		}
	})
	$('#ShowImg').click(function()
	{
		document.getElementById("p").innerHTML = ""
		document.getElementById('img1').style.display = 'initial'
	});
	$('#Link').click(function()
	{
		if(count==0)
		{
			window.location.replace(links[i-1]);
		}
		else
		{
			if(img.src==imageArray[6])
			{
				window.location.replace(links[6]);
			}
			else
			{
				window.location.replace(links[i-1]);
			}
		}
	});
	$('#SettingsButton').click(function()
	{
		window.location.replace("settings.html")
	});
	$('#LoginPgButton').click(function()
	{
		window.location.replace("login pg.html")
	});
})
