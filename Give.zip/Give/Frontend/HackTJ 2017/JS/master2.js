$(document).ready(function()
{
	$('#submit').click(function()
	{
		//how will i print the stuff if i put all of them w/ names? should change all those to IDs
		window.location.replace("charity1.html")
		//window.location.replace("https://www.google.com")
	})
	$('#SettingsButton').click(function()
	{
		window.location.replace("settings.html")
	});
	$('#LoginPgButton').click(function()
	{
		window.location.replace("login pg.html")
	});
	$('#submit').click(function()
	{
		var firstname = $('#firstname').val()
		var lastname = $('#lastname').val()
		var address = $('#address').val()
		var AptNumber = $('#AptNumber').val()
		var state = $('#state').val()
		var country = $('#country').val()
		var type = $('#type').val()
		var CardNum = $('#CardNum').val()
		var cvc = $('#cvc').val()
		var month = $('#month').val()
		var year = $('#year').val()
		console.log("firstname: " + firstname)
		console.log("lastname: " + lastname)
		console.log("address: " + address)
		console.log("AptNumber: " + AptNumber)
		console.log("state: " + state)
		console.log("country: " + country)
		console.log("type: " + type)
		console.log("CardNum: " + CardNum)
		console.log("cvc: " + cvc)
		console.log("month: " + month)
		console.log("year: " + year)
		window.location.replace("charity1.html")
		//window.location.replace("https://www.google.com")
	});
})