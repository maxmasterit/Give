// This is a  line JS comment
/*
   This is a segment JS comment
*/

//var x = 5; // global
//below selector is for selecting tags
$(document).ready(function()
{
	//alert("hi") //creates an alert that says hi
	// console.log("hi katie") //console.log prints into console
	// console.log(x);
	// console.log(x + 7);
	// x = "joe"
	// console.log(x)
	// y = x + 2; // global
	// var z = 2; // local
	// console.log(y)
	// console.log(z)
	//var k = $('#LoginButton')
	


	var LoginBox = document.getElementById('LoginBox');
	// create a simple instance
	// by default, it only adds horizontal recognizers
	var mc = new Hammer(LoginBox);
	// listen to events...
	mc.on("swiperight ", function(ev)
	{
		//donate
		console.log(ev.type, "swipey right")
	});
	mc.on("swipeleft ", function(ev)
	{
		//no donate, and go to next charity
		//see semantic ui transition module for going on to nxt charity
		console.log(ev.type, "swipey left")
	});

	$('#LoginButton').click(function()
	{
		var email = $('#Email').val()
		var password = $('#Password').val()
		console.log("Email: " + email)
		console.log("Password: " + password)
		window.location.replace("charity1.html")
		//window.location.replace("https://www.google.com")
	});
	$('#CreateButton').click(function()
	{
		window.location.replace("CreateAccount.html")
		//window.location.replace("https://www.google.com")
	});
	$('#SettingsButton').click(function()
	{
		window.location.replace("settings.html")
	});
	$('#LoginPgButton').click(function()
	{
		window.location.replace("login pg.html")
	});

})

/*myfunc()

function myfunc(){
	//myfunc(x) would send in x
	//you can return if you want to return something
	console.log("myfunc called")
}*/


/*
selector w/ hashtag selects based on ID
ID is a unique id that one person has
class is a collection of elements that you want to give similar property to
$('#obj1').

selector w/ . selects based on class
$('.obj1').
*/