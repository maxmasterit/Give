$(document).ready(function()
{
	var MainBox = document.getElementById('mainbox');
	var mc = new Hammer(MainBox);
	// listen to events...
	mc.on("swiperight ", function(ev)
	{
		//donate
		console.log(ev.type, "swipey right")
	});
	mc.on("swipeleft ", function(ev)
	{
		//no donate, and go to next charity
		console.log(ev.type, "swipey left")
		window.location.replace("charity6.html")
	});
})
